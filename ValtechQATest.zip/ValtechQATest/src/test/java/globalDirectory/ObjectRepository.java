package globalDirectory;


public class ObjectRepository {
	
	public static String latestNews = ".site-logo__primary .svg-container";
	
	public static String aboutPage = ".icon-menu";

	public static String serivcesPage = "";
	
	public static String workPage = "";

	public static String contactPage = "//a[contains(text(),'Contact Us')]";

	
	

	
}
