package com.valtechProject.Testing;

import java.io.File;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import globalDirectory.Global;
import globalDirectory.ObjectRepository;
import Screens.homePage;
import Screens.aboutPage;
import Screens.contactPage;
import Screens.serivcesPage;
import Screens.workpage;

public class StepDefinition {

	//    Given user navigates to Valtech homepage "URL"
	@Given("^user navigates to Valtech homepage \"([^\"]*)\"$")
	public void user_navigates_to_Valtech_homepage(String url) throws Throwable 
	{
		String exePath = "C:\\valtechWorkspace\\ValtechQATest\\src\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		Global.driver = new ChromeDriver();		
		Global.driver.navigate().to(url);
		Global.driver.manage().window().maximize();
		Global.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	//Then user shoud assert that the "Latest News" sectioon is displyed
	@Then("^user shoud assert that the \"([^\"]*)\" sectioon is displyed$")
	public void user_shoud_assert_that_the_sectioon_is_displyed(String arg1) throws Throwable 
	{
		homePage.navigateToHomePage(arg1);
	}
	
	//When user navigates to "About", "Serivces" and "Work" pages via top navigation and assert that 'H1' tag in each page name. Ex H1 tag in Services page	is displaying as "services"
	@When("^user navigates to \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" pages via top navigation and assert that 'H(\\d+)' tag in each page name\\. Ex H(\\d+) tag in Services page	is displaying as \"([^\"]*)\"$")
	public void user_navigates_to_and_pages_via_top_navigation_and_assert_that_H_tag_in_each_page_name_Ex_H_tag_in_Services_page_is_displaying_as(String arg1, String arg2, String arg3, int arg4, int arg5, String arg6) throws Throwable 
	{
		aboutPage.navigateToaboutPage(arg1);
	}

	//And user then naviagetes to "Contact" page and output how many Valtech offices in total
	@When("^user then naviagetes to \"([^\"]*)\" page and output how many Valtech offices in total$")
	public void user_then_naviagetes_to_page_and_output_how_many_Valtech_offices_in_total(String arg1) throws Throwable 
	{
		
	} 
    
    
}

