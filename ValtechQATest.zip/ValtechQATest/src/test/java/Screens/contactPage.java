package Screens;

import org.openqa.selenium.By;

import globalDirectory.Global;
import globalDirectory.ObjectRepository;

public class contactPage {

	public static void navigateToaboutPage(String arg1){
		
		Global.driver.findElement(By.cssSelector(ObjectRepository.contactPage)).click();
	}
	
	
}
