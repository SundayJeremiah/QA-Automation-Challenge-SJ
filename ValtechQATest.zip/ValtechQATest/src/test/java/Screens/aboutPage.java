package Screens;

import org.junit.Assert;
import org.openqa.selenium.By;

import globalDirectory.Global;
import globalDirectory.ObjectRepository;

public class aboutPage {

	public static void navigateToaboutPage(String arg1){
		
		Global.driver.findElement(By.cssSelector(ObjectRepository.aboutPage)).click();
	}
	
	
		
}
