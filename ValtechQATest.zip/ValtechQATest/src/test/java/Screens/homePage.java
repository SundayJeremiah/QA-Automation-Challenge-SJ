package Screens;

import org.junit.Assert;
import org.openqa.selenium.By;

import globalDirectory.Global;
import globalDirectory.ObjectRepository;

public class homePage {

	public static void navigateToHomePage(String arg1){

	}
	

}
