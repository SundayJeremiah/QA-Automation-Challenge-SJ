package globalDirectory;


public class ObjectRepository {

	
	public static String homePageTitle = ".hero__contents";
	
	public static String vehicleTab = "//*[contains(text(),'Vehicle')]";

	public static String vehicleloopInputField = ".grid__item.five-tenths .vehicleIDLongVIN";
	
	public static String vehicleloopInputField_Sreach = ".grid .grid__item.three-tenths .searchButton";

	public static String vehiclelookupTest = "//h2[starts-with(text(),'Outstanding Field')]";

	
	

	
}
