package globalDirectory;

public class UtilityFunction {

}
