package globalDirectory;

import org.openqa.selenium.WebDriver;

public class Global {

	public static WebDriver driver = null;
	
}
