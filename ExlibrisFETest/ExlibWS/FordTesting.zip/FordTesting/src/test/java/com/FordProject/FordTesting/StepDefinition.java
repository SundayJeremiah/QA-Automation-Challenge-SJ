package com.FordProject.FordTesting;

import java.io.File;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import globalDirectory.Global;
import globalDirectory.ObjectRepository;

public class StepDefinition {

	//Given I navigate to FordEtis Site "<URL>"
	@Given("^I navigate to FordEtis Site \"([^\"]*)\"$")
	public void i_navigate_to_FordEtis_Site(String URL) throws Throwable 
	{		
		String exePath = "C:\\FordWS\\FordTesting\\src\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		Global.driver = new ChromeDriver();		
		Global.driver.navigate().to(URL);
		Global.driver.manage().window().maximize();
		Global.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		Thread.sleep(2000);
	}

	//Then I should "FordEtis home page" displayed
	@Then("^I should \"([^\"]*)\" displayed$")
	public void i_should_displayed(String pageT) throws Throwable 
	{
		String eleTitle = Global.driver.findElement(By.cssSelector(ObjectRepository.homePageTitle)).getText();	
		Assert.assertEquals(pageT, eleTitle);		
	}
	
	//When I click on vehicle tap to be located on vehicle lookup screen
	@When("^I click on vehicle tap to be located on vehicle lookup screen$")
	public void i_click_on_vehicle_tap_to_be_located_on_vehicle_lookup_screen() throws Throwable 
	{
		Thread.sleep(3000);
		Global.driver.findElement(By.xpath(ObjectRepository.vehicleTab)).click();	
		Thread.sleep(3000);

	}

	//And I enter a Registration number in "<Registration_look_up>" input field and click on search
	@When("^I enter a Registration number in \"([^\"]*)\" input field and click on search$")
	public void i_enter_a_Registration_number_in_input_field_and_click_on_search(String regNum) throws Throwable 
	{
		Global.driver.findElement(By.cssSelector(ObjectRepository.vehicleloopInputField)).sendKeys(regNum);
		Global.driver.findElement(By.cssSelector(ObjectRepository.vehicleloopInputField_Sreach)).click();		
	}
		
    //Then I should see "Outstanding Field Service Actions"
	@Then("^I should see \"([^\"]*)\"$")
	public void i_should_see(String lookupDetails) throws Throwable 
	{
		String vehcLookUp = Global.driver.findElement(By.xpath(ObjectRepository.vehiclelookupTest)).getText();		
		Assert.assertEquals(lookupDetails, vehcLookUp);
		Global.driver.quit();		
	}

    
    
    
}

